
export JAVA_HOME=/usr/lib/jvm/java-8-openjdk-amd64
export ZOOKEEPER_HOME=/usr/hdp/current/zookeeper-client
export ZOO_LOG_DIR=/var/log/zookeeper
export ZOOPIDFILE=/var/run/zookeeper/zookeeper_server.pid
export SERVER_JVMFLAGS="-Xmx1024m -XX:+ExitOnOutOfMemoryError -Dwhitelist.filename=NA -Dcomponent=zookeeper-server"
export JAVA=$JAVA_HOME/bin/java
export CLASSPATH=$CLASSPATH:/usr/share/zookeeper/*
export CLIENT_JVMFLAGS="-Dwhitelist.filename=NA -XX:+ExitOnOutOfMemoryError -Dcomponent=zookeeper-client"

