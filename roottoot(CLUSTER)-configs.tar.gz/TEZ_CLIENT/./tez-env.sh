
# Tez specific configuration
export TEZ_CONF_DIR=/etc/tez/2.6.5.3033-1/0

# Set HADOOP_HOME to point to a specific hadoop install directory
export HADOOP_HOME=${HADOOP_HOME:-/usr/hdp/2.6.5.3033-1/hadoop}

# The java implementation to use.
export JAVA_HOME=/usr/lib/jvm/java-8-openjdk-amd64