
JAVA_HOME=/usr/lib/jvm/java-8-openjdk-amd64
HADOOP_HOME=${HADOOP_HOME:-/usr/hdp/2.6.5.3033-1/hadoop}

if [ -d "/usr/lib/tez" ]; then
  PIG_OPTS="$PIG_OPTS -Dmapreduce.framework.name=yarn"
fi